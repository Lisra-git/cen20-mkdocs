#!/bin/bash
a=1
while ((a <= 100)) 
do
  printf -v suffix "%04d" "$a"
  # Début partie à modifier
  echo Employe$suffix   # Affiche dans le terminal NumeroXXXX -- Inspirez-vous pour créer votre arborescence.
  mkdir Employe$suffix
  mkdir Employe$suffix/Autre
  mkdir Employe$suffix/Administratif
  mkdir Employe$suffix/Technique
  # Fin partie à modifier
  ((a += 1))
done
