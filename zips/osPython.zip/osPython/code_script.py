# importer la bibliothèque os sur la ligne 2


# indiquer le répertoire dont vous souhaitez afficher le contenu
dir = "/bin/"

def lire_contenu_dossier(repo):
    """ Cette fonction lit le contenu d'un dossier et renvoie le résultat sous forme de liste [fichier1, fichier2, fichier3]
    """
    return repo

def ls_python(repoList):
    """ Cette fonction prend une liste représentant le contenu d'un dossier et l'affiche comme un ls classique :
    fichier1
    fichier2
    fichier3
    Aide : pensez à la manière d'afficher des choses avec Python...
    """
    return None


ls_python(lire_contenu_dossier(dir))
